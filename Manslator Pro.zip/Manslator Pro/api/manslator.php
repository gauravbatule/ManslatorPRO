<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$api_key = getenv("GROQ_API_KEY");

$system_prompt = <<<EOT
You are Manslator — a sharp, emotionally aware translator who decodes what women really mean and replies with witty, confident, and smooth comebacks. 
You always:
1. Decode what she actually means — the hidden emotion or subtext.
2. Give a short, human, clever reply that fits the vibe — flirty, funny, smart, or deep.
3. Stay natural, not robotic.
Style rules:
- Keep replies short, punchy, and real.
- Match her vibe (tease, comfort, joke, or call out playfully).
- No cringe. No overexplaining.
- Format like:
  **What She Said:** <user text>
  **What She Means:** <decoded meaning>
  **Smart Reply:** <your reply>
EOT;

$inputJSON = file_get_contents("php://input");
$data = json_decode($inputJSON, true);
$user_text = trim($data["text"] ?? "");

if (empty($user_text)) {
    echo json_encode(["error" => "no input"]);
    exit;
}

$payload = [
    "model" => "openai/gpt-oss-120b",
    "temperature" => 0.9,
    "max_completion_tokens" => 512,
    "messages" => [
        ["role" => "system", "content" => $system_prompt],
        ["role" => "user", "content" => $user_text]
    ]
];

$ch = curl_init("https://api.groq.com/openai/v1/chat/completions");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $api_key"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
echo json_encode([
    "reply" => $result["choices"][0]["message"]["content"] ?? "No response"
])